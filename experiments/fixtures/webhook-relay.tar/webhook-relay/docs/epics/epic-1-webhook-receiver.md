---
epic_num: 1
title: Webhook Receiver
status: draft
---

# Epic 1: Webhook Receiver

**Status:** draft
**Priority:** P0
**Stories:** 4

## Overview

Foundation epic for receiving incoming webhooks. Implements the HTTP server using chi router, dynamic endpoint registration, HMAC-SHA256 signature validation, and JSON payload parsing. This epic establishes the core ingress functionality that all other epics depend on.

## Requirements Coverage

- FR-001: Configurable Endpoints
- FR-002: Signature Validation
- FR-003: Payload Parsing
- NFR-001: Handle 1000 req/s per endpoint
- NFR-002: Delivery latency < 100ms

---

## Story 1.1: Create HTTP Server with chi Router

**Status:** draft
**Epic:** Webhook Receiver
**Priority:** P0

## User Story

As a platform engineer, I want the relay service to start an HTTP server so that it can receive incoming webhook requests.

## Acceptance Criteria

1. **AC-1.1.1:** HTTP server starts on configurable port (default 8080, configurable via `RELAY_PORT` environment variable)
2. **AC-1.1.2:** Server uses chi router for request handling with stdlib compatibility
3. **AC-1.1.3:** Server supports graceful shutdown on SIGTERM/SIGINT with configurable timeout
4. **AC-1.1.4:** Request logging middleware logs method, path, status code, and duration for all requests
5. **AC-1.1.5:** Recovery middleware prevents panics from crashing the server and returns 500 response
6. **AC-1.1.6:** Server configuration supports read/write timeouts from config file

## Tasks

- [ ] Task 1: Create server configuration (AC: 1, 6)
  - [ ] Subtask 1.1: Define Config struct with port, timeouts in `internal/config/config.go`
  - [ ] Subtask 1.2: Implement YAML config loading with environment variable override
  - [ ] Subtask 1.3: Add validation for required config values
- [ ] Task 2: Implement HTTP server setup (AC: 2)
  - [ ] Subtask 2.1: Create `internal/server/server.go` with chi router initialization
  - [ ] Subtask 2.2: Configure router with stdlib http.Server wrapper
- [ ] Task 3: Add middleware stack (AC: 4, 5)
  - [ ] Subtask 3.1: Implement request logging middleware with slog
  - [ ] Subtask 3.2: Add panic recovery middleware
  - [ ] Subtask 3.3: Add request ID middleware for tracing
- [ ] Task 4: Implement graceful shutdown (AC: 3)
  - [ ] Subtask 4.1: Set up signal handling for SIGTERM/SIGINT
  - [ ] Subtask 4.2: Implement shutdown with context timeout
- [ ] Task 5: Create main entry point (AC: 1)
  - [ ] Subtask 5.1: Create `cmd/relay/main.go` with server startup

## Technical Notes

- Use `log/slog` for structured logging (Go 1.21+)
- chi middleware ordering: RequestID -> Logger -> Recoverer -> custom
- Server should start even with empty route configuration

## Dependencies

- Requires: None (foundation story)

---

## Story 1.2: Implement Dynamic Endpoint Registration

**Status:** draft
**Epic:** Webhook Receiver
**Priority:** P0

## User Story

As a platform engineer, I want to define webhook endpoints dynamically so that I can configure new integrations without restarting the service.

## Acceptance Criteria

1. **AC-1.2.1:** Routes are loaded from SQLite database on startup
2. **AC-1.2.2:** Each route has unique ID, name, path pattern, and optional signing key
3. **AC-1.2.3:** Webhook endpoint pattern is `/webhook/{route_id}` with path parameter extraction
4. **AC-1.2.4:** In-memory route cache provides O(1) lookup by route ID
5. **AC-1.2.5:** Route changes via Admin API update the cache without restart
6. **AC-1.2.6:** Unknown route IDs return 404 Not Found response

## Tasks

- [ ] Task 1: Create Route model (AC: 2)
  - [ ] Subtask 1.1: Define Route struct in `internal/routing/route.go`
  - [ ] Subtask 1.2: Add JSON serialization tags for API responses
- [ ] Task 2: Set up SQLite storage (AC: 1)
  - [ ] Subtask 2.1: Create `internal/storage/sqlite.go` with connection management
  - [ ] Subtask 2.2: Create routes table schema migration
  - [ ] Subtask 2.3: Implement route CRUD operations
- [ ] Task 3: Implement route cache (AC: 4)
  - [ ] Subtask 3.1: Create `internal/routing/router.go` with in-memory cache
  - [ ] Subtask 3.2: Implement cache loading from database
  - [ ] Subtask 3.3: Add thread-safe cache update methods (AC: 5)
- [ ] Task 4: Create webhook handler (AC: 3, 6)
  - [ ] Subtask 4.1: Create `internal/server/handlers/webhook.go`
  - [ ] Subtask 4.2: Implement route lookup and 404 handling
  - [ ] Subtask 4.3: Register handler on `/webhook/{route_id}` path

## Technical Notes

- Use `sync.RWMutex` for thread-safe cache access
- modernc.org/sqlite is pure Go, no CGO required
- Route ID should be URL-safe (alphanumeric + hyphen)

## Dependencies

- Requires: Story 1.1 (HTTP server)

---

## Story 1.3: Add HMAC Signature Validation

**Status:** draft
**Epic:** Webhook Receiver
**Priority:** P0

## User Story

As an integration developer, I want webhook signatures to be validated so that I can trust that requests are authentic.

## Acceptance Criteria

1. **AC-1.3.1:** Signature header name is configurable per route (default: `X-Signature-256`)
2. **AC-1.3.2:** HMAC-SHA256 signature is computed over raw request body
3. **AC-1.3.3:** Signature format supports both `sha256=<hex>` and raw hex formats
4. **AC-1.3.4:** Invalid or missing signature returns 401 Unauthorized with error message
5. **AC-1.3.5:** Routes without signing key configured skip validation (accept all requests)
6. **AC-1.3.6:** Signature validation uses constant-time comparison to prevent timing attacks

## Tasks

- [ ] Task 1: Extend Route model (AC: 1, 5)
  - [ ] Subtask 1.1: Add `signing_key` and `signature_header` fields to Route
  - [ ] Subtask 1.2: Update database schema migration
- [ ] Task 2: Implement signature validator (AC: 2, 3, 6)
  - [ ] Subtask 2.1: Create signature validation function using crypto/hmac
  - [ ] Subtask 2.2: Support `sha256=<hex>` prefix format
  - [ ] Subtask 2.3: Use hmac.Equal for constant-time comparison
- [ ] Task 3: Integrate validation in handler (AC: 4)
  - [ ] Subtask 3.1: Read raw body for signature computation
  - [ ] Subtask 3.2: Return 401 with JSON error body on failure
  - [ ] Subtask 3.3: Buffer body for subsequent parsing
- [ ] Task 4: Add unit tests
  - [ ] Subtask 4.1: Test valid signature acceptance
  - [ ] Subtask 4.2: Test invalid signature rejection
  - [ ] Subtask 4.3: Test missing signature handling

## Technical Notes

- Use `io.TeeReader` to read body for both signature and parsing
- Signature validation should happen before any payload processing
- Log validation failures with route ID for debugging

## Dependencies

- Requires: Story 1.2 (route with signing key)

---

## Story 1.4: Create Payload Parsing and Validation

**Status:** draft
**Epic:** Webhook Receiver
**Priority:** P0

## User Story

As an integration developer, I want webhook payloads to be parsed and validated so that malformed requests are rejected immediately.

## Acceptance Criteria

1. **AC-1.4.1:** Request body is parsed as JSON with configurable max size (default 1MB)
2. **AC-1.4.2:** Content-Type header must be `application/json` or `application/json; charset=utf-8`
3. **AC-1.4.3:** Malformed JSON returns 400 Bad Request with descriptive error
4. **AC-1.4.4:** Payload exceeding max size returns 413 Payload Too Large
5. **AC-1.4.5:** Empty body returns 400 Bad Request
6. **AC-1.4.6:** Parsed payload is passed to transformation pipeline as `[]byte`

## Tasks

- [ ] Task 1: Add payload configuration (AC: 1)
  - [ ] Subtask 1.1: Add `max_payload_size` to server config
  - [ ] Subtask 1.2: Default to 1MB (1048576 bytes)
- [ ] Task 2: Implement content-type validation (AC: 2)
  - [ ] Subtask 2.1: Parse Content-Type header with mime.ParseMediaType
  - [ ] Subtask 2.2: Accept application/json with any charset parameter
- [ ] Task 3: Implement body size limiting (AC: 4)
  - [ ] Subtask 3.1: Use http.MaxBytesReader to limit body size
  - [ ] Subtask 3.2: Detect MaxBytesError and return 413
- [ ] Task 4: Implement JSON validation (AC: 3, 5)
  - [ ] Subtask 4.1: Use json.Valid to check syntax
  - [ ] Subtask 4.2: Check for empty body before parsing
  - [ ] Subtask 4.3: Return structured error response
- [ ] Task 5: Create payload model (AC: 6)
  - [ ] Subtask 5.1: Define WebhookPayload struct for handler context
  - [ ] Subtask 5.2: Store raw bytes for transformation pipeline

## Technical Notes

- Do not unmarshal to interface{} unless needed - keep as raw bytes
- Error responses should include request ID for debugging
- Log payload size for metrics (but not content)

## Dependencies

- Requires: Story 1.2 (webhook handler foundation)
