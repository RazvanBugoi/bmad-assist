---
epic_num: 2
title: Payload Transformation
status: draft
---

# Epic 2: Payload Transformation

**Status:** draft
**Priority:** P0
**Stories:** 5

## Overview

Implements the transformation pipeline for modifying webhook payloads before delivery to destinations. Supports JSONPath extraction for selecting specific fields, Go template rendering for complex restructuring, and passthrough mode for forwarding unchanged payloads.

## Requirements Coverage

- FR-004: JSONPath Extraction
- FR-005: Go Template Transformation
- FR-006: Passthrough Mode

---

## Story 2.1: Implement JSONPath Extraction

**Status:** draft
**Epic:** Payload Transformation
**Priority:** P0

## User Story

As a platform engineer, I want to extract specific fields from webhook payloads using JSONPath so that I can restructure data before forwarding.

## Acceptance Criteria

1. **AC-2.1.1:** JSONPath expressions follow standard syntax (e.g., `$.data.user.id`, `$.items[0].name`)
2. **AC-2.1.2:** Multiple JSONPath expressions can be combined to build output object
3. **AC-2.1.3:** Missing paths return null values without failing the transformation
4. **AC-2.1.4:** Array expressions (e.g., `$.items[*].id`) return array of values
5. **AC-2.1.5:** Extraction result is a new JSON object with configured field mappings
6. **AC-2.1.6:** Invalid JSONPath syntax is detected at route configuration time

## Tasks

- [ ] Task 1: Add JSONPath library (AC: 1)
  - [ ] Subtask 1.1: Evaluate and select JSONPath library (ohler55/ojg recommended)
  - [ ] Subtask 1.2: Add dependency to go.mod
- [ ] Task 2: Create extraction configuration (AC: 2, 6)
  - [ ] Subtask 2.1: Define JSONPathTransform struct with field mappings
  - [ ] Subtask 2.2: Implement syntax validation for expressions
  - [ ] Subtask 2.3: Add configuration to Route model
- [ ] Task 3: Implement extractor (AC: 1, 3, 4)
  - [ ] Subtask 3.1: Create `internal/transform/jsonpath.go`
  - [ ] Subtask 3.2: Implement single path extraction with null handling
  - [ ] Subtask 3.3: Implement array path extraction
- [ ] Task 4: Build output object (AC: 5)
  - [ ] Subtask 4.1: Iterate field mappings to build result
  - [ ] Subtask 4.2: Marshal result to JSON bytes
- [ ] Task 5: Add unit tests
  - [ ] Subtask 5.1: Test simple path extraction
  - [ ] Subtask 5.2: Test array extraction
  - [ ] Subtask 5.3: Test missing path handling

## Technical Notes

- ohler55/ojg is fast and supports full JSONPath spec
- Precompile JSONPath expressions for performance
- Field mapping format: `{"output_field": "$.input.path"}`

## Dependencies

- Requires: Story 1.4 (parsed payload)

---

## Story 2.2: Add Go Template Transformation

**Status:** draft
**Epic:** Payload Transformation
**Priority:** P0

## User Story

As a platform engineer, I want to transform payloads using Go templates so that I can handle complex restructuring scenarios.

## Acceptance Criteria

1. **AC-2.2.1:** Go text/template syntax is supported with JSON input data
2. **AC-2.2.2:** Template has access to full payload as `.Payload` and metadata as `.Meta`
3. **AC-2.2.3:** Template output must be valid JSON
4. **AC-2.2.4:** Template errors return descriptive error with line/column position
5. **AC-2.2.5:** Custom template functions include: `json`, `default`, `coalesce`, `now`
6. **AC-2.2.6:** Templates are validated at route configuration time

## Tasks

- [ ] Task 1: Create template configuration (AC: 6)
  - [ ] Subtask 1.1: Define TemplateTransform struct in Route
  - [ ] Subtask 1.2: Implement template parsing and validation
- [ ] Task 2: Implement template executor (AC: 1, 2)
  - [ ] Subtask 2.1: Create `internal/transform/template.go`
  - [ ] Subtask 2.2: Build template context with Payload and Meta
  - [ ] Subtask 2.3: Parse input JSON to map for template access
- [ ] Task 3: Add custom functions (AC: 5)
  - [ ] Subtask 3.1: Implement `json` function for re-encoding
  - [ ] Subtask 3.2: Implement `default` for fallback values
  - [ ] Subtask 3.3: Implement `coalesce` for first non-nil
  - [ ] Subtask 3.4: Implement `now` for current timestamp
- [ ] Task 4: Validate output (AC: 3, 4)
  - [ ] Subtask 4.1: Validate template output is valid JSON
  - [ ] Subtask 4.2: Return structured error with position on failure
- [ ] Task 5: Add unit tests
  - [ ] Subtask 5.1: Test basic template rendering
  - [ ] Subtask 5.2: Test custom functions
  - [ ] Subtask 5.3: Test error handling

## Technical Notes

- Use `text/template` not `html/template` (no escaping needed for JSON)
- Pre-parse templates and cache for performance
- Template execution timeout should prevent infinite loops

## Dependencies

- Requires: Story 1.4 (parsed payload)

---

## Story 2.3: Create Transformation Pipeline

**Status:** draft
**Epic:** Payload Transformation
**Priority:** P0

## User Story

As a platform engineer, I want transformations to be composable so that I can chain multiple transformations together.

## Acceptance Criteria

1. **AC-2.3.1:** Transformer interface defines `Transform([]byte) ([]byte, error)` method
2. **AC-2.3.2:** Pipeline executes transformers in configured order
3. **AC-2.3.3:** Each transformer receives output of previous transformer
4. **AC-2.3.4:** Pipeline short-circuits on first error with transformer name in error message
5. **AC-2.3.5:** Empty pipeline passes payload through unchanged
6. **AC-2.3.6:** Pipeline configuration is validated at route creation time

## Tasks

- [ ] Task 1: Define transformer interface (AC: 1)
  - [ ] Subtask 1.1: Create Transformer interface in `internal/transform/transformer.go`
  - [ ] Subtask 1.2: Add Name() method for error context
- [ ] Task 2: Implement pipeline executor (AC: 2, 3, 4, 5)
  - [ ] Subtask 2.1: Create Pipeline struct holding []Transformer
  - [ ] Subtask 2.2: Implement Transform method with chaining
  - [ ] Subtask 2.3: Handle empty pipeline case
  - [ ] Subtask 2.4: Wrap errors with transformer name
- [ ] Task 3: Integrate JSONPath transformer (AC: 1)
  - [ ] Subtask 3.1: Implement Transformer interface for JSONPathTransformer
- [ ] Task 4: Integrate Template transformer (AC: 1)
  - [ ] Subtask 4.1: Implement Transformer interface for TemplateTransformer
- [ ] Task 5: Add pipeline builder (AC: 6)
  - [ ] Subtask 5.1: Create BuildPipeline function from route config
  - [ ] Subtask 5.2: Validate all transformers at build time

## Technical Notes

- Pipeline is built once per route, not per request
- Consider adding metrics for per-transformer timing
- Error wrapping should preserve original error with `%w`

## Dependencies

- Requires: Story 2.1 (JSONPath), Story 2.2 (Template)

---

## Story 2.4: Add Passthrough Mode

**Status:** draft
**Epic:** Payload Transformation
**Priority:** P1

## User Story

As a platform engineer, I want to forward webhooks without transformation so that I can use the relay for routing-only scenarios.

## Acceptance Criteria

1. **AC-2.4.1:** Route with no transformation config uses passthrough by default
2. **AC-2.4.2:** Explicit `"transform": "passthrough"` config is supported
3. **AC-2.4.3:** Passthrough preserves original payload byte-for-byte
4. **AC-2.4.4:** Passthrough mode has minimal performance overhead
5. **AC-2.4.5:** Passthrough is logged distinctly from transform modes

## Tasks

- [ ] Task 1: Implement passthrough transformer (AC: 3, 4)
  - [ ] Subtask 1.1: Create PassthroughTransformer that returns input unchanged
  - [ ] Subtask 1.2: Optimize for zero-copy when possible
- [ ] Task 2: Update pipeline builder (AC: 1, 2)
  - [ ] Subtask 2.1: Detect missing transform config and use passthrough
  - [ ] Subtask 2.2: Handle explicit passthrough config
- [ ] Task 3: Add logging (AC: 5)
  - [ ] Subtask 3.1: Log transform mode with each webhook processing
- [ ] Task 4: Add unit tests
  - [ ] Subtask 4.1: Test default passthrough behavior
  - [ ] Subtask 4.2: Test explicit passthrough config

## Technical Notes

- Passthrough should not copy payload bytes
- May skip JSON validation for passthrough if already validated at ingress

## Dependencies

- Requires: Story 2.3 (pipeline)

---

## Story 2.5: Handle Transformation Errors Gracefully

**Status:** draft
**Epic:** Payload Transformation
**Priority:** P1

## User Story

As a platform engineer, I want transformation errors to be handled gracefully so that I can debug issues and decide on fallback behavior.

## Acceptance Criteria

1. **AC-2.5.1:** Transformation errors are logged with full context (route, payload excerpt, error)
2. **AC-2.5.2:** Route configuration can specify `on_error` behavior: `reject` or `passthrough`
3. **AC-2.5.3:** `reject` mode returns 422 Unprocessable Entity to webhook sender
4. **AC-2.5.4:** `passthrough` mode forwards original payload on transform failure
5. **AC-2.5.5:** Error metrics track transformation failures by route and error type
6. **AC-2.5.6:** Default behavior is `reject` for safety

## Tasks

- [ ] Task 1: Add error handling config (AC: 2, 6)
  - [ ] Subtask 1.1: Add `on_transform_error` field to Route
  - [ ] Subtask 1.2: Default to `reject` if not specified
- [ ] Task 2: Implement reject behavior (AC: 3)
  - [ ] Subtask 2.1: Return 422 with JSON error body
  - [ ] Subtask 2.2: Include error message (sanitized) in response
- [ ] Task 3: Implement passthrough fallback (AC: 4)
  - [ ] Subtask 3.1: Catch transform error and use original payload
  - [ ] Subtask 3.2: Mark delivery as "transformed_with_fallback"
- [ ] Task 4: Add logging and metrics (AC: 1, 5)
  - [ ] Subtask 4.1: Log transformation errors with context
  - [ ] Subtask 4.2: Increment error counter by route and type
- [ ] Task 5: Add unit tests
  - [ ] Subtask 5.1: Test reject behavior
  - [ ] Subtask 5.2: Test passthrough fallback

## Technical Notes

- Payload excerpt in logs should be truncated (first 500 bytes)
- Do not expose internal error details to external callers
- Consider sampling high-volume error logs

## Dependencies

- Requires: Story 2.3 (pipeline)
