# Product Requirements Document: Webhook Relay Service

## Vision

A high-performance webhook relay service that receives incoming webhooks, optionally transforms payloads, and forwards them to multiple destinations with guaranteed delivery. Built for reliability with retry logic, dead letter queues, and comprehensive observability.

## Goals

1. **Reliable Delivery**: Ensure at-least-once delivery of webhooks to all configured destinations
2. **Flexible Transformation**: Support payload transformation via JSONPath and Go templates
3. **High Throughput**: Handle 1000+ requests per second per endpoint
4. **Operational Excellence**: Provide comprehensive metrics, health checks, and admin APIs
5. **Simple Deployment**: Single binary with SQLite for zero-dependency operation

## User Personas

### Platform Engineer
- Configures webhook routes and destinations
- Monitors delivery success rates and latency
- Investigates failed deliveries via dead letter queue
- Manages route configurations via Admin API

### Integration Developer
- Sends webhooks to relay endpoints
- Expects consistent, validated payload acceptance
- Relies on signature verification for security

### Operations Team
- Monitors system health via Prometheus metrics
- Tracks delivery performance and queue depths
- Responds to alerts on delivery failures

## Functional Requirements

### Webhook Reception

- **FR-001: Configurable Endpoints** - Receive webhooks on configurable endpoints with unique paths per source integration
- **FR-002: Signature Validation** - Validate webhook signatures using HMAC-SHA256 with configurable secrets per endpoint
- **FR-003: Payload Parsing** - Parse and validate JSON payloads with proper error responses for malformed data

### Payload Transformation

- **FR-004: JSONPath Extraction** - Transform payloads using JSONPath expressions to extract and restructure data
- **FR-005: Go Template Transformation** - Transform payloads using Go templates for complex restructuring
- **FR-006: Passthrough Mode** - Support passthrough mode that forwards payloads without transformation

### Destination Routing

- **FR-007: Multiple Destinations** - Route webhooks to multiple destinations per source endpoint (fan-out)
- **FR-008: HTTP Destinations** - Support HTTP/HTTPS destinations with configurable method, URL, and timeout
- **FR-009: Custom Headers** - Inject custom headers on outbound requests per destination

### Delivery Reliability

- **FR-010: Retry Logic** - Retry failed deliveries using exponential backoff strategy
- **FR-011: Dead Letter Queue** - Store exhausted retries in dead letter queue for later investigation
- **FR-012: DLQ Replay** - Support replaying messages from dead letter queue

### Admin API

- **FR-013: Route Management** - Admin API to list, create, update, and delete webhook routes
- **FR-014: Destination Management** - Admin API to manage destinations per route
- **FR-015: Delivery History** - Query delivery history with filtering by route, status, and time range
- **FR-016: DLQ Operations** - View and manage dead letter queue entries

### Observability

- **FR-017: Prometheus Metrics** - Expose Prometheus-compatible metrics endpoint
- **FR-018: Health Check** - Provide health check endpoint for load balancer integration

## Non-Functional Requirements

### Performance

- **NFR-001: Throughput** - Handle 1000 requests per second per endpoint under sustained load
- **NFR-002: Latency** - Delivery latency < 100ms (p95) excluding destination response time
- **NFR-003: Concurrency** - Support concurrent delivery to multiple destinations without blocking

### Reliability

- **NFR-004: Delivery Guarantee** - Provide at-least-once delivery guarantee for all accepted webhooks
- **NFR-005: Retry Policy** - Retry failed deliveries 3 times with backoff intervals of 1s, 5s, 30s
- **NFR-006: DLQ Retention** - Retain dead letter queue entries for 7 days before automatic purge

### Quality

- **NFR-007: Test Coverage** - Maintain test coverage above 80%
- **NFR-008: Single Binary** - Deploy as single binary with embedded migrations

## MVP Scope

### In Scope
- HTTP webhook reception with signature validation
- JSONPath and Go template transformations
- HTTP destination routing with retry
- Dead letter queue with replay
- Admin API for configuration
- Prometheus metrics and health checks

### Out of Scope
- WebSocket destinations
- gRPC destinations
- Message queue destinations (Kafka, RabbitMQ)
- Multi-node clustering
- Web UI dashboard
- Authentication on receiver endpoints (use secrets in URL path)
- Rate limiting on outbound requests

## Success Metrics

- Webhook delivery success rate > 99.9%
- p95 delivery latency < 100ms
- Zero data loss for accepted webhooks
- Admin API response time < 50ms
