# Project Context: Webhook Relay Service

## File Structure

```
cmd/
├── relay/
│   └── main.go                 # Application entry point
internal/
├── config/
│   └── config.go               # Configuration loading (YAML + env)
├── server/
│   ├── server.go               # HTTP server setup
│   ├── middleware.go           # Common middleware
│   └── handlers/
│       ├── webhook.go          # Webhook receiver handlers
│       ├── admin.go            # Admin API handlers
│       └── health.go           # Health check handlers
├── routing/
│   ├── router.go               # Route registry and lookup
│   ├── route.go                # Route model
│   └── destination.go          # Destination model
├── transform/
│   ├── transformer.go          # Transformation interface
│   ├── jsonpath.go             # JSONPath extractor
│   └── template.go             # Go template transformer
├── delivery/
│   ├── sender.go               # HTTP delivery client
│   ├── queue.go                # Delivery queue
│   ├── retry.go                # Retry logic with backoff
│   └── dlq.go                  # Dead letter queue
├── storage/
│   ├── sqlite.go               # SQLite connection management
│   └── migrations.go           # Schema migrations
└── metrics/
    └── prometheus.go           # Prometheus metric definitions
tests/
├── integration/
│   └── delivery_test.go        # Integration tests
└── e2e/
    └── relay_test.go           # End-to-end tests
```

## Naming Conventions

### Files
- Use `snake_case` for all Go source files
- Test files: `*_test.go`
- Migrations: `NNNN_description.sql`

### Packages
- Lowercase single word (e.g., `routing`, `delivery`, `transform`)
- Avoid stuttering in imports (use `routing.Route` not `routing.RoutingRoute`)

### Types and Functions
- **Exported structs:** PascalCase (e.g., `Route`, `Destination`, `DeliveryResult`)
- **Exported functions:** PascalCase (e.g., `NewRouter`, `SendWebhook`)
- **Internal functions:** camelCase (e.g., `parseConfig`, `validateSignature`)
- **Interfaces:** PascalCase with `-er` suffix when appropriate (e.g., `Transformer`, `Sender`)

### Variables and Constants
- **Variables:** camelCase (e.g., `routeID`, `maxRetries`)
- **Constants:** PascalCase for exported, ALL_CAPS for environment variable names
- **Struct fields:** PascalCase for JSON marshaling

### HTTP Routes
- Use kebab-case for URL paths (e.g., `/admin/dead-letter-queue`)
- Use path parameters with descriptive names (e.g., `/routes/{route_id}`)

## Go Patterns

### Error Handling

Always wrap errors with context using `fmt.Errorf`:

```go
func (r *Router) GetRoute(id string) (*Route, error) {
    route, err := r.storage.FindRoute(id)
    if err != nil {
        return nil, fmt.Errorf("get route %s: %w", id, err)
    }
    if route == nil {
        return nil, ErrRouteNotFound
    }
    return route, nil
}
```

Define sentinel errors for expected conditions:

```go
var (
    ErrRouteNotFound      = errors.New("route not found")
    ErrInvalidSignature   = errors.New("invalid webhook signature")
    ErrDeliveryFailed     = errors.New("delivery failed after retries")
)
```

### Interface Design

Define interfaces close to usage, keep them small:

```go
// In transform/transformer.go
type Transformer interface {
    Transform(payload []byte) ([]byte, error)
}

// In delivery/sender.go
type Sender interface {
    Send(ctx context.Context, dest *Destination, payload []byte) error
}
```

### Dependency Injection

Use constructor functions that accept dependencies:

```go
type WebhookHandler struct {
    router      *routing.Router
    transformer transform.Transformer
    sender      delivery.Sender
    metrics     *metrics.Collector
}

func NewWebhookHandler(
    router *routing.Router,
    transformer transform.Transformer,
    sender delivery.Sender,
    metrics *metrics.Collector,
) *WebhookHandler {
    return &WebhookHandler{
        router:      router,
        transformer: transformer,
        sender:      sender,
        metrics:     metrics,
    }
}
```

### Context Propagation

Always pass context as first parameter, use for cancellation and timeouts:

```go
func (s *HTTPSender) Send(ctx context.Context, dest *Destination, payload []byte) error {
    ctx, cancel := context.WithTimeout(ctx, dest.Timeout)
    defer cancel()

    req, err := http.NewRequestWithContext(ctx, http.MethodPost, dest.URL, bytes.NewReader(payload))
    if err != nil {
        return fmt.Errorf("create request: %w", err)
    }
    // ...
}
```

### Struct Tags

Use consistent JSON tags with snake_case:

```go
type Route struct {
    ID           string        `json:"id"`
    Name         string        `json:"name"`
    SigningKey   string        `json:"signing_key,omitempty"`
    Destinations []Destination `json:"destinations"`
    CreatedAt    time.Time     `json:"created_at"`
    UpdatedAt    time.Time     `json:"updated_at"`
}
```

## Testing Standards

### Test Organization

```go
func TestRouter_GetRoute(t *testing.T) {
    t.Run("returns route when exists", func(t *testing.T) {
        // Arrange
        storage := newMockStorage()
        storage.routes["test-id"] = &Route{ID: "test-id", Name: "Test"}
        router := NewRouter(storage)

        // Act
        route, err := router.GetRoute("test-id")

        // Assert
        require.NoError(t, err)
        assert.Equal(t, "Test", route.Name)
    })

    t.Run("returns error when not found", func(t *testing.T) {
        // ...
    })
}
```

### Test Naming

- Use `Test<Type>_<Method>` for unit tests
- Use descriptive subtests with `t.Run`
- Use table-driven tests for multiple cases

### Mocking

Create mock implementations in `*_test.go` files or a `mocks/` package:

```go
type mockSender struct {
    sendFunc func(ctx context.Context, dest *Destination, payload []byte) error
}

func (m *mockSender) Send(ctx context.Context, dest *Destination, payload []byte) error {
    return m.sendFunc(ctx, dest, payload)
}
```

### Integration Tests

Use build tags for integration tests:

```go
//go:build integration

package integration

func TestDeliveryPipeline(t *testing.T) {
    // Tests requiring real SQLite database
}
```

Run with: `go test -tags=integration ./tests/integration/...`

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `RELAY_PORT` | HTTP server port | `8080` |
| `RELAY_DB_PATH` | SQLite database path | `./relay.db` |
| `RELAY_LOG_LEVEL` | Log level (debug, info, warn, error) | `info` |
| `RELAY_ADMIN_TOKEN` | Admin API authentication token | (required) |
| `RELAY_MAX_RETRIES` | Maximum delivery retries | `3` |
| `RELAY_DLQ_RETENTION_DAYS` | Days to retain DLQ entries | `7` |

### YAML Configuration

```yaml
server:
  port: 8080
  read_timeout: 30s
  write_timeout: 30s

database:
  path: ./relay.db
  max_connections: 10

delivery:
  timeout: 10s
  max_retries: 3
  backoff:
    - 1s
    - 5s
    - 30s

admin:
  token: ${RELAY_ADMIN_TOKEN}

metrics:
  enabled: true
  path: /metrics
```

## Logging

Use structured logging with `slog`:

```go
import "log/slog"

func (h *WebhookHandler) HandleWebhook(w http.ResponseWriter, r *http.Request) {
    routeID := chi.URLParam(r, "route_id")
    logger := slog.With(
        "route_id", routeID,
        "request_id", r.Header.Get("X-Request-ID"),
    )

    logger.Info("webhook received")

    if err := h.processWebhook(r); err != nil {
        logger.Error("webhook processing failed", "error", err)
        // ...
    }
}
```
